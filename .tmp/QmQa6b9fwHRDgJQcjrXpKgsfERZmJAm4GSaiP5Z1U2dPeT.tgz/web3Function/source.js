// web3-functions/counter-checker/index.ts
import { Web3Function } from "@gelatonetwork/web3-functions-sdk";
import { Contract, Interface } from "ethers";
var COUNTER_ABI = [
  "function count() view returns (uint256)",
  "function increaseCount(uint256) external"
];
Web3Function.onRun(async (context) => {
  const { userArgs, multiChainProvider } = context;
  const provider = multiChainProvider.default();
  const counterAddress = userArgs.counterAddress;
  const threshold = parseInt(userArgs.threshold);
  if (!counterAddress) {
    return { canExec: false, message: "Missing counterAddress in userArgs" };
  }
  const counter = new Contract(counterAddress, COUNTER_ABI, provider);
  try {
    const currentCount = Number(await counter.count());
    console.log(`Current count: ${currentCount}, Threshold: ${threshold}`);
    if (currentCount < threshold) {
      const iface = new Interface(COUNTER_ABI);
      const callData = iface.encodeFunctionData("increaseCount", [1]);
      return {
        canExec: true,
        callData: [{
          to: counterAddress,
          data: callData
        }]
      };
    } else {
      return {
        canExec: false,
        message: `Current count (${currentCount}) is not below threshold (${threshold})`
      };
    }
  } catch (error) {
    console.error("Error in web3 function:", error);
    return {
      canExec: false,
      message: `Error: ${error instanceof Error ? error.message : String(error)}`
    };
  }
});
